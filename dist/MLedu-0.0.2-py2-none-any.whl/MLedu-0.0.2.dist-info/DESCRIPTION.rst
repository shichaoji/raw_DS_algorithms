build data science models for learning


