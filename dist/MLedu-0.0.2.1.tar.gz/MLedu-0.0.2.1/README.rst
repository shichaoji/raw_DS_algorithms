build data science models from scratch for learning purposes
